enum Role {
  Admin = "Admin",
  Editor = "Editor",
  Viewer = "Viewer",
}
export default Role;
